(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [185], {
        8828: function(e, s, a) {
            Promise.resolve().then(a.bind(a, 552)), Promise.resolve().then(a.t.bind(a, 3247, 23)), Promise.resolve().then(a.t.bind(a, 8877, 23))
        },
        552: function(e, s, a) {
            "use strict";
            var t = a(7437),
                l = a(2265),
                r = a(7138);
            s.default = () => {
                let [e, s] = (0, l.useState)(!1);
                return (0, t.jsxs)("nav", {
                    className: "bg-white pt-10 shadow-md",
                    children: [(0, t.jsxs)("div", {
                        className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex justify-between items-center",
                        children: [(0, t.jsxs)("div", {
                            className: "flex items-center",
                            children: [(0, t.jsxs)("div", {
                                className: "text-red-600 text-4xl font-bold flex items-center",
                                children: [(0, t.jsx)("span", {
                                    className: "mr-2",
                                    children: (0, t.jsx)("img", {
                                        src: "/assets/icons/fire.svg",
                                        alt: "fire icon"
                                    })
                                }), " uifry"]
                            }), (0, t.jsxs)("div", {
                                className: "hidden md:flex ml-10 space-x-8",
                                children: [(0, t.jsx)(r.default, {
                                    href: "/",
                                    legacyBehavior: !0,
                                    children: (0, t.jsx)("a", {
                                        className: "text-red-600 font-bold",
                                        children: "Home"
                                    })
                                }), (0, t.jsx)(r.default, {
                                    href: "/about",
                                    legacyBehavior: !0,
                                    children: (0, t.jsx)("a", {
                                        className: "text-gray-900",
                                        children: "About Us"
                                    })
                                }), (0, t.jsx)(r.default, {
                                    href: "/pricing",
                                    legacyBehavior: !0,
                                    children: (0, t.jsx)("a", {
                                        className: "text-gray-900",
                                        children: "Pricing"
                                    })
                                }), (0, t.jsx)(r.default, {
                                    href: "/features",
                                    legacyBehavior: !0,
                                    children: (0, t.jsx)("a", {
                                        className: "text-gray-900",
                                        children: "Features"
                                    })
                                })]
                            })]
                        }), (0, t.jsx)("div", {
                            className: "hidden md:flex",
                            children: (0, t.jsx)("button", {
                                className: "bg-black text-white py-2 px-4 rounded",
                                children: "Download"
                            })
                        }), (0, t.jsx)("div", {
                            className: "md:hidden flex items-center",
                            children: (0, t.jsx)("button", {
                                onClick: () => {
                                    s(!e)
                                },
                                className: "text-black focus:outline-none",
                                children: (0, t.jsx)("svg", {
                                    className: "w-6 h-6",
                                    fill: "none",
                                    stroke: "currentColor",
                                    viewBox: "0 0 24 24",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: (0, t.jsx)("path", {
                                        strokeLinecap: "round",
                                        strokeLinejoin: "round",
                                        strokeWidth: "2",
                                        d: "M4 6h16M4 12h16M4 18h16"
                                    })
                                })
                            })
                        })]
                    }), e && (0, t.jsxs)("div", {
                        className: "md:hidden",
                        children: [(0, t.jsxs)("div", {
                            className: "px-2 pt-2 pb-3 space-y-1 sm:px-3 text-center",
                            children: [(0, t.jsx)(r.default, {
                                href: "/",
                                legacyBehavior: !0,
                                children: (0, t.jsx)("a", {
                                    className: "block px-3 py-2 rounded-md text-base font-medium text-red-600",
                                    children: "Home"
                                })
                            }), (0, t.jsx)(r.default, {
                                href: "/about",
                                legacyBehavior: !0,
                                children: (0, t.jsx)("a", {
                                    className: "block px-3 py-2 rounded-md text-base font-medium text-gray-900",
                                    children: "About Us"
                                })
                            }), (0, t.jsx)(r.default, {
                                href: "/pricing",
                                legacyBehavior: !0,
                                children: (0, t.jsx)("a", {
                                    className: "block px-3 py-2 rounded-md text-base font-medium text-gray-900",
                                    children: "Pricing"
                                })
                            }), (0, t.jsx)(r.default, {
                                href: "/features",
                                legacyBehavior: !0,
                                children: (0, t.jsx)("a", {
                                    className: "block px-3 py-2 rounded-md text-base font-medium text-gray-900",
                                    children: "Features"
                                })
                            })]
                        }), (0, t.jsx)("div", {
                            className: "px-2 pb-3",
                            children: (0, t.jsx)("button", {
                                className: "w-full bg-black text-white py-2 px-4 rounded",
                                children: "Download"
                            })
                        })]
                    })]
                })
            }
        },
        8877: function() {}
    },
    function(e) {
        e.O(0, [569, 37, 971, 23, 744], function() {
            return e(e.s = 8828)
        }), _N_E = e.O()
    }
]);